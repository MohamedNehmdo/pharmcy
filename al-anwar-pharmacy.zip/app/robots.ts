import type { MetadataRoute } from "next"

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/api/", "/checkout/", "/orders/"],
      },
    ],
    sitemap: "https://al-anwar-pharmacy.vercel.app/sitemap.xml",
  }
}
